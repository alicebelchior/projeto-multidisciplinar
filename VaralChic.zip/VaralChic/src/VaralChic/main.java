package VaralChic;

import VaralChic.views.frmSplash;

public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Chamar a tela "frmSplash" para iniciar o programa
        frmSplash splash = new frmSplash();
        
        //chamar a tela para torna-la visivel
        splash.setVisible(true);
    }

}
