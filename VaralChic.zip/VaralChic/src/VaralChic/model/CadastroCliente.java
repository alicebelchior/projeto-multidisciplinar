package VaralChic.model;

/**
 *
 * @author alice
 */
//RESPONSÁVEL PELO CADASTRO DE CLIENTE E TRAZER AS INFORMAÇÕES DOS CAMPOS DA TELA "CadastroCliente"
public class CadastroCliente {

    //ATRIBUTOS ESTÁTICOS
    public static int codigo_cliente;
    public static String nome_cliente;
    public static String cpf_cliente;
    public static String rg_cliente;
    public static String endereco_cliente;
    public static String telefone_cliente;
    public static String email_cliente;
    public static String observacao;
}
