
package VaralChic.model;

/**
 *
 * @author alice
 */

//RESPONSÁVEL PELO CADASTRO DE PRODUTO E TRAZER AS INFORMAÇÕES DOS CAMPOS DA TELA "CadastroProduto"
public class CadastroProduto {
    //ATRIBUTOS ESTÁTICOS
    public static int codigo_produto;
    public static String categoria;
    public static int quantidade_estoque;
    public static float preco;
}
