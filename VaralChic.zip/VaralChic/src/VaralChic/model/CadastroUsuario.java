package VaralChic.model;

/**
 *
 * @author alice
 */

//RESPONSÁVEL PELO CADASTRO DE CLIENTE E TRAZER AS INFORMAÇÕES DOS CAMPOS DA TELA "CadastroCliente"
public class CadastroUsuario {
    
    //ATRIBUTOS ESTÁTICOS
    public static int codigo_usuario;
    public static String nome;
    public static String cpf_usuario;
    public static String telefone;
    public static String usuario;
    public static String senha;
}
