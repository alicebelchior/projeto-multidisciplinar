
/*
    Classe responsavel por pegar os dados digitados pelo usuario na "TelaLogin"
*/
package VaralChic.model;

public class Login {
    
    //criação dos atributos
    public static String usuario;
    public static String senha;
}